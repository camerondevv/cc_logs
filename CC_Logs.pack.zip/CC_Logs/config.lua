Config = {}

Config.Webhook = "" -- Discord Webhook Here

Config.EnableLogs = true 
Config.LogTitle = "CC Logs" 
Config.LogColor = 16711680 
Config.FooterText = "CC Server Logs" 

Config.ShowHealth = true
Config.ShowPing = true
Config.ShowSteamHex = true
Config.ShowDiscordInfo = true

Config.EnableLeaveLogs = true
Config.LeaveLogColor = 16776960 
Config.LeaveLogTitle = "Player Left"
Config.LeaveLogFooter = "CC Leave Logs"

Config.EnableChatLogs = true 
Config.ChatLogWebhook = ""  -- Discord Webhook Here
Config.ChatLogColor = 3447003 
Config.ChatLogTitle = "Chat Message"
Config.ChatLogFooter = "CC Chat Logs"
