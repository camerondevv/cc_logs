fx_version 'cerulean'
game 'gta5'

author 'Camerons Customs'
description 'CC Customs Discord Logs/w FiveM'
version '1.0.0'
lua54 'yes'

escrow_ignore {
	"config.lua"
}

server_script {
    'config.lua',
    'server.lua'
}
dependency '/assetpacks'
dependency '/assetpacks'